# 政务舆情分析平台前后端原型

当前项目已经包含：

- 本地 `Node` 后端服务
- 首页总览后端聚合接口
- 监测页后端聚合接口
- 事件详情后端聚合接口
- 预警中心后端聚合接口
- 自动翻译能力
- 静态页面与样式资源

## 启动方式

在项目目录执行：

```bash
npm start
```

启动后访问：

```text
http://localhost:4173
```

## 打包桌面版 EXE

在项目目录执行：

```bash
npm run build:exe
```

执行完成后，会在桌面生成：

```text
GovInsightConsole.exe
```

## 当前接口

- `/api/health`
- `/api/dashboard`
- `/api/monitor?filter=all`
- `/api/monitor?filter=service`
- `/api/monitor?filter=policy`
- `/api/monitor?filter=urban`
- `/api/monitor?filter=petition`
- `/api/events`
- `/api/events?id=事件ID`
- `/api/events/:id`
- `/api/warnings`

说明：

- 所有接口都支持追加 `refresh` 查询参数，例如 `/api/dashboard?refresh=1`
- 带 `refresh` 参数时，后端会清空聚合缓存并重新拉取数据

## 数据说明

- 公开资讯：`HN Algolia`
- 自动翻译：`MyMemory`
- 本地后端负责聚合、缓存、翻译和衍生字段计算，前端负责展示与交互

## 页面说明

- `index.html`：态势总览，展示聚合指标、主题热度、趋势和重点事件
- `monitor.html`：舆情监测，展示分类筛选、实时资讯流和监测列表
- `detail.html`：事件详情，展示摘要、时间线、情绪结构、处置建议和关联事件
- `warning.html`：预警中心，展示分级预警统计、触发规则、值班队列和预警事件清单
