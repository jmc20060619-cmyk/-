const http = require("http");
const fs = require("fs/promises");
const path = require("path");
const { spawn } = require("child_process");
const sea = require("node:sea");

const PORT = Number(process.env.PORT || 4173);
const IS_SEA = typeof sea.isSea === "function" && sea.isSea();
const ROOT_DIR = IS_SEA ? path.dirname(process.execPath) : __dirname;
const API_CACHE_TTL_MS = 60 * 1000;
const TRANSLATION_TTL_MS = 24 * 60 * 60 * 1000;
const SEA_STATIC_ASSET_KEYS = new Set([
  "app.js",
  "detail.html",
  "index.html",
  "monitor.html",
  "styles.css",
  "warning.html"
]);

const STATIC_MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml"
};

const QUERY_CONFIG = {
  all: { label: "全部", query: "government" },
  service: { label: "民生服务", query: "public service" },
  policy: { label: "政策传播", query: "policy" },
  urban: { label: "城市治理", query: "transportation" },
  petition: { label: "网络问政", query: "complaint" }
};

const DASHBOARD_KEYS = ["service", "policy", "urban", "petition"];

const WARNING_RULES = [
  {
    title: "传播增速 > 200%",
    description: "30 分钟内互动热度快速增长时，自动升级为重点关注。"
  },
  {
    title: "评论互动 > 45",
    description: "当评论量持续抬升时，进入人工研判队列。"
  },
  {
    title: "跨源传播 >= 3",
    description: "同类话题在多个来源出现时，自动加入联动跟踪列表。"
  }
];

const ACTION_LIBRARY = {
  petition: [
    { title: "统一回应口径", description: "梳理网络问政与留言反馈中的高频诉求，统一形成外部回应口径。" },
    { title: "核查办理时效", description: "调取办理链路节点，确认是否存在超时或部门衔接不畅的问题。" },
    { title: "同步通报进展", description: "通过政务新媒体与留言平台同步说明处置进展，降低重复发酵风险。" }
  ],
  policy: [
    { title: "发布权威解读", description: "围绕政策执行边界、适用对象和时间节点进行清晰解释，减少误读。" },
    { title: "监测二次传播", description: "重点观察转述、摘要和视频解读内容，防止出现偏差传播。" },
    { title: "准备答疑提纲", description: "针对公众关心的核心问题准备统一问答模板，提升回应效率。" }
  ],
  urban: [
    { title: "补充公开信息", description: "围绕施工、交通、治理安排发布进度和配套说明，降低信息不对称。" },
    { title: "研判区域影响", description: "结合评论和传播源，评估对周边居民、出行和服务场景的影响。" },
    { title: "建立跨部门联动", description: "需要多个部门协同时，提前约定口径和处置节奏。" }
  ],
  service: [
    { title: "核查服务流程", description: "优先梳理群众反映最集中的环节，定位是否存在流程拥堵或告知不足。" },
    { title: "优化热线回应", description: "检查热线与线上渠道的反馈速度，避免重复投诉继续发酵。" },
    { title: "发布改进举措", description: "围绕服务便利性和办理效率形成阶段性改进说明。" }
  ],
  default: [
    { title: "保持持续监测", description: "结合传播热度和评论情况动态调整处置优先级。" },
    { title: "补充研判材料", description: "持续收集来源、评论和时间线信息，为后续会商提供支撑。" },
    { title: "同步内部通报", description: "对重要节点形成简报，确保处置动作与舆情走势同步。" }
  ]
};

const FALLBACK_STORIES = [
  {
    category: "service",
    title: "Public service complaint volumes continue to rise after hotline update",
    url: "https://example.com/public-service-hotline",
    author: "fallback",
    created_at: "2026-03-11T08:00:00.000Z",
    objectID: "fallback-service-1",
    points: 42,
    num_comments: 18
  },
  {
    category: "policy",
    title: "Policy clarification campaign launched to reduce interpretation gaps",
    url: "https://example.com/policy-clarification",
    author: "fallback",
    created_at: "2026-03-11T07:20:00.000Z",
    objectID: "fallback-policy-1",
    points: 33,
    num_comments: 11
  },
  {
    category: "urban",
    title: "Transportation construction debate spreads across regional media",
    url: "https://example.com/urban-transportation",
    author: "fallback",
    created_at: "2026-03-10T21:30:00.000Z",
    objectID: "fallback-urban-1",
    points: 29,
    num_comments: 9
  },
  {
    category: "petition",
    title: "Online petition threads call for faster response from local departments",
    url: "https://example.com/online-petition",
    author: "fallback",
    created_at: "2026-03-10T19:40:00.000Z",
    objectID: "fallback-petition-1",
    points: 24,
    num_comments: 8
  }
];

const apiCache = new Map();
const translationCache = new Map();

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "no-store",
    "Content-Type": "application/json; charset=utf-8"
  });
  response.end(JSON.stringify(payload));
}

function sendNotFound(response) {
  response.writeHead(404, {
    "Content-Type": "text/plain; charset=utf-8"
  });
  response.end("Not Found");
}

function sendError(response, statusCode, errorMessage) {
  sendJson(response, statusCode, {
    error: errorMessage
  });
}

function getStaticMimeType(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  return STATIC_MIME_TYPES[extension] || "application/octet-stream";
}

async function readBundledStaticAsset(assetKey) {
  if (IS_SEA) {
    if (!SEA_STATIC_ASSET_KEYS.has(assetKey)) {
      throw new Error("ASSET_NOT_FOUND");
    }

    return Buffer.from(sea.getAsset(assetKey));
  }

  return fs.readFile(path.join(ROOT_DIR, assetKey));
}

function openBrowser(url) {
  if (process.platform !== "win32") {
    return;
  }

  const child = spawn("cmd", ["/c", "start", "", url], {
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });

  child.unref();
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function getRisk(score) {
  if (score >= 100) {
    return { text: "高", className: "badge-warn" };
  }
  if (score >= 45) {
    return { text: "中", className: "badge-mid" };
  }
  return { text: "低", className: "badge-safe" };
}

function getWarningLevel(score) {
  if (score >= 100) {
    return { text: "红色", className: "badge-warn" };
  }
  if (score >= 45) {
    return { text: "橙色", className: "badge-mid" };
  }
  return { text: "黄色", className: "badge-safe" };
}

function buildAdvice(categoryKey, score) {
  if (categoryKey === "service") {
    return score >= 45 ? "建议同步核查民生反馈和热线响应进度" : "建议保持民生类话题跟踪";
  }
  if (categoryKey === "policy") {
    return score >= 45 ? "建议准备权威解读与统一口径说明" : "建议持续跟踪政策传播表现";
  }
  if (categoryKey === "urban") {
    return score >= 45 ? "建议补充交通与施工信息公开" : "建议关注城市治理相关议题";
  }
  if (categoryKey === "petition") {
    return score >= 45 ? "建议核查线上诉求办理与回应时效" : "建议跟踪网络问政和留言反馈";
  }
  return "建议保持持续监测";
}

function buildTrigger(categoryKey, score, sourceCount = 1) {
  const sourceTrigger = sourceCount >= 3 ? "跨源传播" : "单源扩散";

  if (categoryKey === "service") {
    return score >= 45 ? `热线反馈 + ${sourceTrigger}` : `服务讨论 + ${sourceTrigger}`;
  }
  if (categoryKey === "policy") {
    return score >= 45 ? `政策误读 + ${sourceTrigger}` : `政策讨论 + ${sourceTrigger}`;
  }
  if (categoryKey === "urban") {
    return score >= 45 ? `治理话题升温 + ${sourceTrigger}` : `城市议题跟踪`;
  }
  if (categoryKey === "petition") {
    return score >= 45 ? `问政互动升高 + ${sourceTrigger}` : `留言诉求跟踪`;
  }
  return sourceTrigger;
}

function extractDomain(urlValue) {
  if (!urlValue) {
    return "news.ycombinator.com";
  }

  try {
    return new URL(urlValue).hostname.replace(/^www\./, "");
  } catch {
    return "news.ycombinator.com";
  }
}

function shouldTranslate(text) {
  if (!text) {
    return false;
  }

  const hasChinese = /[\u3400-\u9FFF]/u.test(text);
  const hasLatin = /[A-Za-z]/.test(text);
  return hasLatin && !hasChinese;
}

function formatDayLabel(date) {
  return `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
}

function formatTimeLabel(value) {
  const date = new Date(value);
  return `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function shiftIsoTime(value, minutes) {
  const date = new Date(value);
  date.setMinutes(date.getMinutes() + minutes);
  return date.toISOString();
}

function normalizeStory(item, categoryKey) {
  const originalTitle = item.title || item.story_title || "Untitled story";
  const objectId = item.objectID || item.story_id || `${categoryKey}-${Buffer.from(originalTitle).toString("hex").slice(0, 10)}`;
  const urlValue = item.url || `https://news.ycombinator.com/item?id=${objectId}`;
  const points = Number(item.points || 0);
  const comments = Number(item.num_comments || 0);

  return {
    id: String(objectId),
    category: categoryKey,
    categoryLabel: QUERY_CONFIG[categoryKey]?.label || QUERY_CONFIG.all.label,
    originalTitle,
    url: urlValue,
    source: extractDomain(urlValue),
    author: item.author || "anonymous",
    createdAt: item.created_at || new Date().toISOString(),
    points,
    comments,
    score: points + comments
  };
}

async function withCache(cacheMap, cacheKey, ttlMs, loader) {
  const existing = cacheMap.get(cacheKey);
  if (existing && Date.now() - existing.timestamp < ttlMs) {
    return existing.value;
  }

  try {
    const value = await loader();
    cacheMap.set(cacheKey, {
      timestamp: Date.now(),
      value
    });
    return value;
  } catch (error) {
    if (existing) {
      return existing.value;
    }
    throw error;
  }
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: {
      Accept: "application/json"
    },
    signal: AbortSignal.timeout(12_000)
  });

  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }

  return response.json();
}

function buildFallbackResponse(filterKey, hitsPerPage) {
  const fallbackItems = FALLBACK_STORIES
    .filter((story) => filterKey === "all" || story.category === filterKey)
    .slice(0, hitsPerPage);

  return {
    hits: fallbackItems,
    nbHits: fallbackItems.length
  };
}

async function fetchStories(filterKey, hitsPerPage) {
  const config = QUERY_CONFIG[filterKey] || QUERY_CONFIG.all;
  const cacheKey = `stories:${filterKey}:${hitsPerPage}`;

  return withCache(apiCache, cacheKey, API_CACHE_TTL_MS, async() => {
    try {
      const url = new URL("https://hn.algolia.com/api/v1/search_by_date");
      url.searchParams.set("query", config.query);
      url.searchParams.set("tags", "story");
      url.searchParams.set("hitsPerPage", String(hitsPerPage));
      return await fetchJson(url.toString());
    } catch {
      return buildFallbackResponse(filterKey, hitsPerPage);
    }
  });
}

async function translateText(text) {
  const input = String(text || "").trim();
  if (!shouldTranslate(input)) {
    return null;
  }

  return withCache(translationCache, input, TRANSLATION_TTL_MS, async() => {
    try {
      const url = new URL("https://api.mymemory.translated.net/get");
      url.searchParams.set("q", input);
      url.searchParams.set("langpair", "en|zh-CN");
      const data = await fetchJson(url.toString());
      const translated = data.responseData?.translatedText;
      if (!translated || translated.includes("INVALID SOURCE LANGUAGE")) {
        return null;
      }
      return translated;
    } catch {
      return null;
    }
  });
}

async function enrichStories(stories) {
  return Promise.all(
    stories.map(async(story) => ({
      ...story,
      translatedTitle: await translateText(story.originalTitle)
    }))
  );
}

function buildSourceDistribution(stories) {
  const counts = new Map();
  stories.forEach((story) => {
    counts.set(story.source, (counts.get(story.source) || 0) + 1);
  });

  const total = stories.length || 1;
  return Array.from(counts.entries())
    .sort((left, right) => right[1] - left[1])
    .slice(0, 5)
    .map(([label, count]) => ({
      label,
      count,
      percent: Math.round((count / total) * 100)
    }));
}

function buildTrend(stories) {
  const counts = new Map();
  stories.forEach((story) => {
    const date = new Date(story.createdAt);
    const key = date.toISOString().slice(0, 10);
    counts.set(key, (counts.get(key) || 0) + 1);
  });

  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - index));
    const key = date.toISOString().slice(0, 10);
    return {
      key,
      label: formatDayLabel(date),
      count: counts.get(key) || 0
    };
  });
}

function buildCategoryHeat(categoryPayloads) {
  const total = categoryPayloads.reduce((sum, category) => sum + category.totalHits, 0) || 1;

  return categoryPayloads.map((category) => ({
    key: category.key,
    label: category.label,
    totalHits: category.totalHits,
    percent: Math.round((category.totalHits / total) * 100)
  }));
}

function buildHeadline(categoryHeat) {
  const sorted = [...categoryHeat].sort((left, right) => right.totalHits - left.totalHits);
  const first = sorted[0];
  const second = sorted[1];

  if (!first) {
    return "公开资讯面保持平稳，当前未检索到新的重点话题";
  }

  if (!second) {
    return `${first.label}是当前最主要的关注方向`;
  }

  return `${first.label}热度居前，${second.label}讨论量紧随其后`;
}

function combineStories(categoryPayloads) {
  const stories = [];
  const seen = new Set();

  categoryPayloads.forEach((categoryPayload) => {
    categoryPayload.items.forEach((story) => {
      if (!seen.has(story.id)) {
        seen.add(story.id);
        stories.push(story);
      }
    });
  });

  return stories.sort((left, right) => {
    if (right.score !== left.score) {
      return right.score - left.score;
    }
    return new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime();
  });
}

async function loadStoryUniverse(hitsPerPage = 16) {
  return withCache(apiCache, `universe:${hitsPerPage}`, API_CACHE_TTL_MS, async() => {
    const categoryPayloads = await Promise.all(
      DASHBOARD_KEYS.map(async(key) => {
        const response = await fetchStories(key, hitsPerPage);
        return {
          key,
          label: QUERY_CONFIG[key].label,
          totalHits: Number(response.nbHits || 0),
          items: (response.hits || []).map((story) => normalizeStory(story, key))
        };
      })
    );

    return {
      categoryPayloads,
      stories: combineStories(categoryPayloads)
    };
  });
}

function buildEventNarrative(eventItem, relatedItems) {
  const spreadText = relatedItems.length >= 2 ? "同类内容已在多个来源持续出现" : "当前仍以单类来源讨论为主";
  return `${eventItem.categoryLabel}相关内容当前热度值为 ${eventItem.score}，来源 ${eventItem.source} 的互动较为集中。${spreadText}，建议结合原文与评论继续复核。`;
}

function buildEventSentiment(eventItem) {
  const negative = clamp(30 + Math.round(eventItem.score / 4) + Math.round(eventItem.comments / 8), 32, 72);
  const positive = clamp(18 + Math.round(eventItem.points / 12) - Math.round(eventItem.comments / 14), 8, 26);
  const neutral = Math.max(8, 100 - negative - positive);
  const adjustedNegative = 100 - positive - neutral;

  return [
    { label: "负向", value: adjustedNegative },
    { label: "中性", value: neutral },
    { label: "正向", value: positive }
  ];
}

function buildEventTimeline(eventItem, relatedItems) {
  const nodes = [eventItem, ...relatedItems].sort((left, right) => new Date(left.createdAt) - new Date(right.createdAt));

  return nodes.slice(0, 4).map((item, index) => {
    const stage = index === 0 ? "首个节点" : index === nodes.length - 1 ? "当前节点" : "传播扩散";
    return {
      time: formatTimeLabel(item.createdAt),
      title: stage,
      originalTitle: item.originalTitle,
      translatedTitle: item.translatedTitle || null,
      description: `${item.source} 出现相关内容，互动热度 ${item.score}，评论 ${item.comments}。`
    };
  });
}

function buildEventActions(categoryKey) {
  return ACTION_LIBRARY[categoryKey] || ACTION_LIBRARY.default;
}

async function buildDashboardPayload() {
  return withCache(apiCache, "payload:dashboard", API_CACHE_TTL_MS, async() => {
    const { categoryPayloads, stories } = await loadStoryUniverse(12);
    const topStories = await enrichStories(stories.slice(0, 6));
    const translationCount = topStories.filter((story) => story.translatedTitle).length;
    const reviewCount = topStories.filter((story) => story.score >= 45).length;
    const highHeatCount = topStories.filter((story) => story.score >= 100).length;
    const categoryHeat = buildCategoryHeat(categoryPayloads);
    const totalHits = categoryPayloads.reduce((sum, category) => sum + category.totalHits, 0);
    const overviewStatus = highHeatCount >= 2 ? { text: "需重点关注", className: "badge-warn" } : reviewCount >= 2 ? { text: "持续观察", className: "badge-mid" } : { text: "总体平稳", className: "badge-safe" };

    return {
      sourceName: "HN Algolia + MyMemory",
      updatedAt: new Date().toISOString(),
      overview: {
        headline: buildHeadline(categoryHeat),
        summary: `后端已汇聚 ${totalHits.toLocaleString("en-US")} 条公开资讯，自动翻译覆盖前 ${topStories.length} 条重点内容，建议优先复核 ${reviewCount} 条高讨论事件。`,
        statusText: overviewStatus.text,
        statusClass: overviewStatus.className
      },
      stats: {
        totalHits,
        keyEvents: topStories.length,
        translatedItems: translationCount,
        translationCoverage: topStories.length ? Math.round((translationCount / topStories.length) * 100) : 0,
        pendingReview: reviewCount,
        highHeat: highHeatCount
      },
      categoryHeat,
      trend: buildTrend(stories),
      sources: buildSourceDistribution(stories),
      events: topStories.map((story) => {
        const risk = getRisk(story.score);
        return {
          ...story,
          riskText: risk.text,
          riskClass: risk.className,
          advice: buildAdvice(story.category, story.score)
        };
      })
    };
  });
}

async function buildMonitorPayload(filterKey) {
  const filter = QUERY_CONFIG[filterKey] ? filterKey : "all";
  return withCache(apiCache, `payload:monitor:${filter}`, API_CACHE_TTL_MS, async() => {
    const response = await fetchStories(filter, 8);
    const normalizedStories = (response.hits || []).map((story) => normalizeStory(story, filter === "all" ? "all" : filter));
    const items = await enrichStories(normalizedStories);
    const translatedItems = items.filter((story) => story.translatedTitle).length;
    const domains = buildSourceDistribution(items).map((item) => item.label);

    return {
      sourceName: "HN Algolia + MyMemory",
      updatedAt: new Date().toISOString(),
      filter,
      label: QUERY_CONFIG[filter].label,
      totalHits: Number(response.nbHits || items.length),
      translatedItems,
      items: items.map((story) => {
        const risk = getRisk(story.score);
        return {
          ...story,
          riskText: risk.text === "高" ? "高热度" : risk.text === "中" ? "持续跟踪" : "常规关注",
          riskClass: risk.className
        };
      }),
      tags: [QUERY_CONFIG[filter].label, ...domains.slice(0, 5)]
    };
  });
}

async function buildEventPayload(eventId) {
  return withCache(apiCache, `payload:event:${eventId || "default"}`, API_CACHE_TTL_MS, async() => {
    const { stories } = await loadStoryUniverse(16);
    const selectedBase = stories.find((story) => story.id === eventId) || stories[0];

    if (!selectedBase) {
      return {
        sourceName: "HN Algolia + MyMemory",
        updatedAt: new Date().toISOString(),
        event: null,
        timeline: [],
        sentiment: [],
        actions: [],
        related: []
      };
    }

    const relatedBase = stories
      .filter((story) => story.category === selectedBase.category && story.id !== selectedBase.id)
      .slice(0, 4);

    const [selected] = await enrichStories([selectedBase]);
    const related = await enrichStories(relatedBase);
    const risk = getRisk(selected.score);
    const peakTime = shiftIsoTime(selected.createdAt, 90);
    const sentiment = buildEventSentiment(selected);
    const timeline = buildEventTimeline(selected, related);
    const actions = buildEventActions(selected.category);

    return {
      sourceName: "HN Algolia + MyMemory",
      updatedAt: new Date().toISOString(),
      event: {
        ...selected,
        riskText: risk.text,
        riskClass: risk.className,
        summary: buildEventNarrative(selected, related),
        firstSeen: selected.createdAt,
        peakTime,
        spreadStatus: related.length >= 2 ? "跨源传播" : "单源讨论",
        sourceCount: buildSourceDistribution([selected, ...related]).length
      },
      timeline,
      sentiment,
      actions,
      related: related.map((story) => ({
        ...story,
        riskClass: getRisk(story.score).className
      }))
    };
  });
}

async function buildWarningsPayload() {
  return withCache(apiCache, "payload:warnings", API_CACHE_TTL_MS, async() => {
    const dashboard = await buildDashboardPayload();
    const warningItems = dashboard.events.slice(0, 6).map((eventItem, index) => {
      const level = getWarningLevel(eventItem.score);
      const sourceCount = dashboard.sources.filter((source) => source.label === eventItem.source).length + 1;
      return {
        ...eventItem,
        levelText: level.text,
        levelClass: level.className,
        trigger: buildTrigger(eventItem.category, eventItem.score, sourceCount),
        ownerStatus: index === 0 ? "已派发" : index < 3 ? "待研判" : "跟踪中",
        detailUrl: `./detail.html?id=${encodeURIComponent(eventItem.id)}`
      };
    });

    const counts = warningItems.reduce(
      (summary, item) => {
        if (item.levelText === "红色") {
          summary.red += 1;
        } else if (item.levelText === "橙色") {
          summary.orange += 1;
        } else {
          summary.yellow += 1;
        }
        return summary;
      },
      { red: 0, orange: 0, yellow: 0 }
    );

    const duty = [
      { name: "值班一组", summary: `处理中 ${Math.max(1, counts.red + Math.ceil(counts.orange / 2))} 件` },
      { name: "值班二组", summary: `处理中 ${Math.max(1, Math.floor(counts.orange / 2) + Math.ceil(counts.yellow / 2))} 件` },
      { name: "研判专班", summary: `待复核 ${dashboard.stats.pendingReview} 件` }
    ];

    return {
      sourceName: dashboard.sourceName,
      updatedAt: new Date().toISOString(),
      stats: {
        red: counts.red,
        orange: counts.orange,
        yellow: counts.yellow,
        closed: Math.max(6, dashboard.stats.keyEvents + counts.yellow)
      },
      rules: WARNING_RULES,
      duty,
      warnings: warningItems
    };
  });
}

async function handleApiRequest(requestUrl, response) {
  if (requestUrl.searchParams.has("refresh")) {
    apiCache.clear();
  }

  if (requestUrl.pathname === "/api/health") {
    sendJson(response, 200, {
      status: "ok",
      timestamp: new Date().toISOString()
    });
    return;
  }

  if (requestUrl.pathname === "/api/dashboard") {
    sendJson(response, 200, await buildDashboardPayload());
    return;
  }

  if (requestUrl.pathname === "/api/monitor") {
    sendJson(response, 200, await buildMonitorPayload(requestUrl.searchParams.get("filter") || "all"));
    return;
  }

  if (requestUrl.pathname.startsWith("/api/events/")) {
    const eventId = decodeURIComponent(requestUrl.pathname.replace("/api/events/", ""));
    sendJson(response, 200, await buildEventPayload(eventId));
    return;
  }

  if (requestUrl.pathname === "/api/events") {
    sendJson(response, 200, await buildEventPayload(requestUrl.searchParams.get("id") || ""));
    return;
  }

  if (requestUrl.pathname === "/api/warnings") {
    sendJson(response, 200, await buildWarningsPayload());
    return;
  }

  sendNotFound(response);
}

async function serveStaticFile(requestUrl, response) {
  const relativePath = requestUrl.pathname === "/" ? "index.html" : decodeURIComponent(requestUrl.pathname.slice(1));
  const safePath = path.normalize(relativePath).replace(/^(\.\.[/\\])+/, "");
  const assetKey = safePath.replaceAll("\\", "/");
  const filePath = path.join(ROOT_DIR, safePath);

  try {
    if (!IS_SEA && !filePath.startsWith(ROOT_DIR)) {
      sendNotFound(response);
      return;
    }

    const content = await readBundledStaticAsset(assetKey);
    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Type": getStaticMimeType(assetKey)
    });
    response.end(content);
  } catch {
    sendNotFound(response);
  }
}

const server = http.createServer(async(request, response) => {
  try {
    if (request.method !== "GET") {
      sendError(response, 405, "Method not allowed");
      return;
    }

    const requestUrl = new URL(request.url, `http://${request.headers.host}`);

    if (requestUrl.pathname.startsWith("/api/")) {
      await handleApiRequest(requestUrl, response);
      return;
    }

    await serveStaticFile(requestUrl, response);
  } catch (error) {
    console.error(error);
    sendError(response, 500, "Internal server error");
  }
});

function startServer(port, retriesLeft = 10) {
  server.once("error", (error) => {
    if (error && error.code === "EADDRINUSE" && retriesLeft > 0) {
      startServer(port + 1, retriesLeft - 1);
      return;
    }

    console.error(error);
    process.exit(1);
  });

  server.listen(port, () => {
    const baseUrl = `http://localhost:${port}`;
    console.log(`Server ready at ${baseUrl}`);

    if (IS_SEA) {
      openBrowser(`${baseUrl}/index.html`);
    }
  });
}

startServer(PORT);
