const currentPage = document.body.dataset.page || "";
const API_BASE = window.location.protocol === "file:" ? "http://localhost:4173" : "";
const PAGE_REFRESH_MS = 60_000;

const pageState = {
  dashboard: {
    payload: null,
    timer: null,
    translationEnabled: readPreference("dashboard_translation", true)
  },
  monitor: {
    payload: null,
    timer: null,
    currentFilter: "all",
    translationEnabled: readPreference("monitor_translation", true)
  },
  detail: {
    payload: null,
    timer: null,
    currentId: "",
    translationEnabled: readPreference("detail_translation", true)
  },
  warning: {
    payload: null,
    timer: null,
    translationEnabled: readPreference("warning_translation", true)
  }
};

const activeButtonSelectors = [
  '[data-action="refresh-dashboard"]',
  '[data-action="toggle-dashboard-translation"]',
  '[data-action="refresh-monitor"]',
  '[data-action="toggle-monitor-translation"]',
  '[data-action="refresh-detail"]',
  '[data-action="toggle-detail-translation"]',
  '[data-action="refresh-warning"]',
  '[data-action="toggle-warning-translation"]'
];

let toastTimer = null;

document.querySelectorAll("[data-nav]").forEach((link) => {
  if (link.dataset.nav === currentPage) {
    link.classList.add("is-active");
  }
});

function readPreference(key, fallbackValue) {
  try {
    const savedValue = window.localStorage.getItem(key);
    return savedValue === null ? fallbackValue : savedValue === "true";
  } catch {
    return fallbackValue;
  }
}

function writePreference(key, value) {
  try {
    window.localStorage.setItem(key, String(value));
  } catch {
    // Ignore localStorage failures.
  }
}

function showToast(message) {
  let toast = document.querySelector(".toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);
  }

  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add("is-visible");

  toastTimer = window.setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 2200);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function formatDateTime(value) {
  if (!value) {
    return "--";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "--";
  }

  return date.toLocaleString("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString("zh-CN");
}

function appendRefreshParam(path, forceRefresh) {
  if (!forceRefresh) {
    return path;
  }

  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}refresh=${Date.now()}`;
}

function getDisplayTitle(item, translationEnabled) {
  if (!item) {
    return "--";
  }

  return translationEnabled && item.translatedTitle ? item.translatedTitle : item.originalTitle || item.title || "--";
}

function getSecondaryTitle(item, translationEnabled) {
  if (!item) {
    return "";
  }

  return translationEnabled && item.translatedTitle ? item.originalTitle || "" : item.translatedTitle || "";
}

function renderTitleStack(item, translationEnabled, href = "") {
  const secondary = getSecondaryTitle(item, translationEnabled);
  const content = `
    <div class="title-stack">
      <span class="title-primary">${escapeHtml(getDisplayTitle(item, translationEnabled))}</span>
      ${secondary ? `<span class="title-secondary">${escapeHtml(secondary)}</span>` : ""}
    </div>
  `;

  if (!href) {
    return content;
  }

  return `<a class="title-link" href="${escapeHtml(href)}">${content}</a>`;
}

function setButtonLabel(selector, label, disabled = false) {
  const button = document.querySelector(selector);
  if (!button) {
    return;
  }

  button.disabled = disabled;
  button.textContent = label;
}

function setStatusText(elementId, value) {
  const element = document.getElementById(elementId);
  if (element) {
    element.textContent = value;
  }
}

function setVisibility(elementId, isVisible) {
  const element = document.getElementById(elementId);
  if (element) {
    element.classList.toggle("is-hidden", !isVisible);
  }
}

function setDashboardTranslationButtonLabel() {
  const enabled = pageState.dashboard.translationEnabled;
  setButtonLabel('[data-action="toggle-dashboard-translation"]', `自动翻译：${enabled ? "开" : "关"}`);
}

function setMonitorTranslationButtonLabel() {
  const enabled = pageState.monitor.translationEnabled;
  setButtonLabel('[data-action="toggle-monitor-translation"]', `自动翻译：${enabled ? "开" : "关"}`);
}

function setDetailTranslationButtonLabel() {
  const enabled = pageState.detail.translationEnabled;
  setButtonLabel('[data-action="toggle-detail-translation"]', `自动翻译：${enabled ? "开" : "关"}`);
}

function setWarningTranslationButtonLabel() {
  const enabled = pageState.warning.translationEnabled;
  setButtonLabel('[data-action="toggle-warning-translation"]', `自动翻译：${enabled ? "开" : "关"}`);
}

async function requestJson(path) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      Accept: "application/json"
    }
  });

  if (!response.ok) {
    throw new Error(`请求失败: ${response.status}`);
  }

  return response.json();
}

function renderDashboardCategoryHeat(items) {
  const container = document.getElementById("dashboard-category-heat");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = '<p class="empty-state">当前暂无主题热度数据。</p>';
    return;
  }

  container.innerHTML = items
    .map((item) => `
      <div class="category-item">
        <div class="category-row">
          <span>${escapeHtml(item.label)}</span>
          <strong>${item.percent}%</strong>
        </div>
        <div class="category-bar">
          <i style="width: ${Math.max(item.percent, 6)}%"></i>
        </div>
        <p class="category-foot">${formatNumber(item.totalHits)} 条公开资讯</p>
      </div>
    `)
    .join("");
}

function renderDashboardTrend(items) {
  const container = document.getElementById("dashboard-trend-list");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = '<p class="empty-state">当前暂无趋势数据。</p>';
    return;
  }

  const maxCount = Math.max(...items.map((item) => item.count), 1);
  container.innerHTML = items
    .map((item) => `
      <div class="trend-row">
        <span class="trend-label">${escapeHtml(item.label)}</span>
        <div class="trend-track">
          <i class="trend-fill" style="width: ${(item.count / maxCount) * 100}%"></i>
        </div>
        <strong>${escapeHtml(String(item.count))}</strong>
      </div>
    `)
    .join("");
}

function renderDashboardSources(items) {
  const container = document.getElementById("dashboard-source-list");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = '<p class="empty-state">当前暂无来源构成数据。</p>';
    return;
  }

  container.innerHTML = items
    .map((item) => `
      <div class="source-item">
        <span>${escapeHtml(item.label)}</span>
        <strong>${item.percent}%</strong>
      </div>
    `)
    .join("");
}

function renderDashboardEvents(items) {
  const tableBody = document.getElementById("dashboard-table-body");
  const emptyState = document.getElementById("dashboard-table-empty");
  if (!tableBody || !emptyState) {
    return;
  }

  if (!items.length) {
    tableBody.innerHTML = "";
    emptyState.classList.remove("is-hidden");
    return;
  }

  emptyState.classList.add("is-hidden");
  tableBody.innerHTML = items
    .map((item) => `
      <tr>
        <td>${renderTitleStack(item, pageState.dashboard.translationEnabled, `./detail.html?id=${encodeURIComponent(item.id)}`)}</td>
        <td>${escapeHtml(item.categoryLabel)}</td>
        <td>${escapeHtml(String(item.score))}</td>
        <td><span class="badge ${item.riskClass}">${escapeHtml(item.riskText)}</span></td>
        <td>${escapeHtml(item.source)}</td>
        <td>${escapeHtml(item.advice)}</td>
      </tr>
    `)
    .join("");
}

function renderDashboard(payload) {
  pageState.dashboard.payload = payload;

  setStatusText("dashboard-source-status", `后端在线：${payload.sourceName}`);
  setStatusText("dashboard-updated", `最近更新：${formatDateTime(payload.updatedAt)}`);
  setStatusText("dashboard-headline", payload.overview.headline);
  setStatusText("dashboard-summary", payload.overview.summary);

  const statusBadge = document.getElementById("dashboard-status");
  if (statusBadge) {
    statusBadge.textContent = payload.overview.statusText;
    statusBadge.className = `badge ${payload.overview.statusClass}`;
  }

  setStatusText("metric-total-hits", formatNumber(payload.stats.totalHits));
  setStatusText("metric-key-events", formatNumber(payload.stats.keyEvents));
  setStatusText("metric-translation-rate", `${payload.stats.translationCoverage}%`);
  setStatusText("metric-total-hits-note", "后端聚合统计");
  setStatusText("metric-key-events-note", "按热度自动排序");
  setStatusText("metric-translation-note", `${payload.stats.translatedItems} 条已翻译`);

  setStatusText("stat-high-heat", formatNumber(payload.stats.highHeat));
  setStatusText("stat-service-total", formatNumber(payload.categoryHeat.find((item) => item.key === "service")?.totalHits || 0));
  setStatusText("stat-translated-items", formatNumber(payload.stats.translatedItems));
  setStatusText("stat-pending-review", formatNumber(payload.stats.pendingReview));
  setStatusText("dashboard-trend-meta", "按最近 7 天公开资讯数量聚合");

  renderDashboardCategoryHeat(payload.categoryHeat || []);
  renderDashboardTrend(payload.trend || []);
  renderDashboardSources(payload.sources || []);
  renderDashboardEvents(payload.events || []);
  setDashboardTranslationButtonLabel();
}

async function loadDashboard(forceRefresh = false) {
  try {
    setButtonLabel('[data-action="refresh-dashboard"]', forceRefresh ? "正在刷新..." : "刷新总览", true);
    const payload = await requestJson(appendRefreshParam("/api/dashboard", forceRefresh));
    renderDashboard(payload);
  } catch (error) {
    console.error(error);
    setStatusText("dashboard-source-status", "后端请求失败");
    setStatusText("dashboard-updated", "最近更新：--");
    showToast("首页总览暂时无法获取后端数据，请确认本地服务已启动。");
  } finally {
    setButtonLabel('[data-action="refresh-dashboard"]', "刷新总览", false);
  }
}

function renderMonitorTags(items) {
  const container = document.getElementById("tag-cloud");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = '<p class="empty-state">当前暂无标签数据。</p>';
    return;
  }

  container.innerHTML = items
    .map((item, index) => {
      const className = index === 0 ? "tag-large" : index < 4 ? "tag-medium" : "tag-small";
      return `<span class="${className}">${escapeHtml(item)}</span>`;
    })
    .join("");
}

function renderMonitorFeed(items) {
  const feedList = document.getElementById("feed-list");
  const emptyState = document.getElementById("feed-empty");
  if (!feedList || !emptyState) {
    return;
  }

  if (!items.length) {
    feedList.innerHTML = "";
    emptyState.classList.remove("is-hidden");
    return;
  }

  emptyState.classList.add("is-hidden");
  feedList.innerHTML = items
    .map((item) => `
      <article class="feed-item">
        <div>
          ${renderTitleStack(item, pageState.monitor.translationEnabled, `./detail.html?id=${encodeURIComponent(item.id)}`)}
          <p>来源：${escapeHtml(item.source)} / 发布时间：${escapeHtml(formatDateTime(item.createdAt))} / 作者：${escapeHtml(item.author)}</p>
        </div>
        <span class="badge ${item.riskClass}">${escapeHtml(item.riskText)}</span>
      </article>
    `)
    .join("");
}

function renderMonitorTable(items) {
  const tableBody = document.getElementById("topic-table-body");
  const emptyState = document.getElementById("table-empty");
  if (!tableBody || !emptyState) {
    return;
  }

  if (!items.length) {
    tableBody.innerHTML = "";
    emptyState.classList.remove("is-hidden");
    return;
  }

  emptyState.classList.add("is-hidden");
  tableBody.innerHTML = items
    .map((item) => `
      <tr>
        <td>${renderTitleStack(item, pageState.monitor.translationEnabled, `./detail.html?id=${encodeURIComponent(item.id)}`)}</td>
        <td>${escapeHtml(item.source)}</td>
        <td>${escapeHtml(formatDateTime(item.createdAt))}</td>
        <td>${escapeHtml(String(item.score))}</td>
        <td>${escapeHtml(String(item.comments))}</td>
        <td>
          <div class="link-group">
            <a class="text-link" href="./detail.html?id=${encodeURIComponent(item.id)}">查看事件</a>
            <a class="text-link" href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">查看原文</a>
          </div>
        </td>
      </tr>
    `)
    .join("");
}

function renderMonitor(payload) {
  pageState.monitor.payload = payload;

  setStatusText("monitor-source-status", `后端在线：${payload.sourceName}`);
  setStatusText("monitor-updated", `最近更新：${formatDateTime(payload.updatedAt)}`);
  setStatusText("monitor-feed-title", `${payload.label}公开资讯流`);
  setStatusText("monitor-feed-meta", `共检索到 ${formatNumber(payload.totalHits)} 条公开资讯，当前展示最新 ${payload.items.length} 条`);

  renderMonitorFeed(payload.items || []);
  renderMonitorTable(payload.items || []);
  renderMonitorTags(payload.tags || []);
  setMonitorTranslationButtonLabel();
}

async function loadMonitor(filter, forceRefresh = false) {
  pageState.monitor.currentFilter = filter;

  try {
    setButtonLabel('[data-action="refresh-monitor"]', forceRefresh ? "正在刷新..." : "刷新实时数据", true);
    const payload = await requestJson(appendRefreshParam(`/api/monitor?filter=${encodeURIComponent(filter)}`, forceRefresh));
    renderMonitor(payload);
  } catch (error) {
    console.error(error);
    setStatusText("monitor-source-status", "后端请求失败");
    setStatusText("monitor-updated", "最近更新：--");
    showToast("监测页暂时无法获取后端数据，请确认本地服务已启动。");
  } finally {
    setButtonLabel('[data-action="refresh-monitor"]', "刷新实时数据", false);
  }
}

function renderDetailTimeline(items) {
  const container = document.getElementById("detail-timeline");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("detail-timeline-empty", true);
    return;
  }

  setVisibility("detail-timeline-empty", false);
  container.innerHTML = items
    .map((item) => `
      <div class="timeline-item">
        <span class="timeline-time">${escapeHtml(item.time || "--")}</span>
        <div>
          <h4>${escapeHtml(item.title)}</h4>
          ${renderTitleStack(item, pageState.detail.translationEnabled)}
          <p>${escapeHtml(item.description)}</p>
        </div>
      </div>
    `)
    .join("");
}

function renderDetailSentiment(items) {
  const container = document.getElementById("detail-sentiment-bars");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("detail-sentiment-empty", true);
    return;
  }

  setVisibility("detail-sentiment-empty", false);
  container.innerHTML = items
    .map((item) => `
      <div class="bar-row">
        <span>${escapeHtml(item.label)}</span>
        <div class="bar"><i style="width: ${Math.max(4, Number(item.value) || 0)}%"></i></div>
        <strong>${escapeHtml(String(item.value))}%</strong>
      </div>
    `)
    .join("");
}

function renderDetailActions(items) {
  const container = document.getElementById("detail-action-list");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("detail-action-empty", true);
    return;
  }

  setVisibility("detail-action-empty", false);
  container.innerHTML = items
    .map((item, index) => `
      <article class="action-item">
        <h4>${index + 1}. ${escapeHtml(item.title)}</h4>
        <p>${escapeHtml(item.description)}</p>
      </article>
    `)
    .join("");
}

function renderDetailRelated(items) {
  const container = document.getElementById("detail-related-list");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("detail-related-empty", true);
    return;
  }

  setVisibility("detail-related-empty", false);
  container.innerHTML = items
    .map((item) => `
      <article class="feed-item">
        <div>
          ${renderTitleStack(item, pageState.detail.translationEnabled, `./detail.html?id=${encodeURIComponent(item.id)}`)}
          <p>来源：${escapeHtml(item.source)} / 发布时间：${escapeHtml(formatDateTime(item.createdAt))} / 热度：${escapeHtml(String(item.score))}</p>
        </div>
        <div class="link-group">
          <a class="text-link" href="./detail.html?id=${encodeURIComponent(item.id)}">查看详情</a>
          <a class="text-link" href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">查看原文</a>
        </div>
      </article>
    `)
    .join("");
}

function syncDetailUrl(eventId) {
  if (!eventId || !window.history?.replaceState) {
    return;
  }

  const url = new URL(window.location.href);
  if (url.searchParams.get("id") === eventId) {
    return;
  }

  url.searchParams.set("id", eventId);
  window.history.replaceState({}, "", `${url.pathname}${url.search}`);
}

function renderDetail(payload) {
  pageState.detail.payload = payload;

  setStatusText("detail-source-status", `后端在线：${payload.sourceName}`);
  setStatusText("detail-updated", `最近更新：${formatDateTime(payload.updatedAt)}`);

  if (!payload.event) {
    setStatusText("detail-sidebar-title", "暂无可用事件");
    setStatusText("detail-sidebar-summary", "当前没有可展示的事件数据，请稍后刷新。");
    setStatusText("detail-title", "暂无可用事件");
    setStatusText("detail-title-note", "请稍后刷新或从监测页重新进入事件详情。");
    setStatusText("detail-first-seen", "首次发现：--");
    setStatusText("detail-peak-time", "传播峰值：--");
    setStatusText("detail-spread-status", "传播状态：--");
    setStatusText("detail-summary-text", "当前没有后端返回的事件摘要。");

    const badge = document.getElementById("detail-risk-badge");
    if (badge) {
      badge.textContent = "待分析";
      badge.className = "badge badge-safe";
    }

    renderDetailTimeline([]);
    renderDetailSentiment([]);
    renderDetailActions([]);
    renderDetailRelated([]);
    setDetailTranslationButtonLabel();
    document.title = "政务舆情分析平台 - 事件详情";
    return;
  }

  const eventItem = payload.event;
  pageState.detail.currentId = eventItem.id;
  syncDetailUrl(eventItem.id);

  const title = getDisplayTitle(eventItem, pageState.detail.translationEnabled);
  const secondaryTitle = getSecondaryTitle(eventItem, pageState.detail.translationEnabled);

  setStatusText("detail-sidebar-title", title);
  setStatusText("detail-sidebar-summary", eventItem.summary);
  setStatusText("detail-title", title);
  setStatusText("detail-title-note", secondaryTitle || `${eventItem.categoryLabel} / ${eventItem.source}`);
  setStatusText("detail-first-seen", `首次发现：${formatDateTime(eventItem.firstSeen)}`);
  setStatusText("detail-peak-time", `传播峰值：${formatDateTime(eventItem.peakTime)}`);
  setStatusText("detail-spread-status", `传播状态：${eventItem.spreadStatus}`);
  setStatusText("detail-summary-text", eventItem.summary);

  const badge = document.getElementById("detail-risk-badge");
  if (badge) {
    badge.textContent = eventItem.riskText;
    badge.className = `badge ${eventItem.riskClass}`;
  }

  renderDetailTimeline(payload.timeline || []);
  renderDetailSentiment(payload.sentiment || []);
  renderDetailActions(payload.actions || []);
  renderDetailRelated(payload.related || []);
  setDetailTranslationButtonLabel();
  document.title = `${title} - 政务舆情分析平台`;
}

async function loadDetail(eventId = "", forceRefresh = false) {
  const targetId = eventId || pageState.detail.currentId;
  if (targetId) {
    pageState.detail.currentId = targetId;
  }

  try {
    setButtonLabel('[data-action="refresh-detail"]', forceRefresh ? "正在刷新..." : "刷新事件", true);
    const path = targetId ? `/api/events?id=${encodeURIComponent(targetId)}` : "/api/events";
    const payload = await requestJson(appendRefreshParam(path, forceRefresh));
    renderDetail(payload);
  } catch (error) {
    console.error(error);
    setStatusText("detail-source-status", "后端请求失败");
    setStatusText("detail-updated", "最近更新：--");
    showToast("事件详情暂时无法获取后端数据，请确认本地服务已启动。");
  } finally {
    setButtonLabel('[data-action="refresh-detail"]', "刷新事件", false);
  }
}

function renderWarningRules(items) {
  const container = document.getElementById("warning-rules-list");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("warning-rules-empty", true);
    return;
  }

  setVisibility("warning-rules-empty", false);
  container.innerHTML = items
    .map((item) => `
      <div class="rule-item">
        <strong>${escapeHtml(item.title)}</strong>
        <p>${escapeHtml(item.description)}</p>
      </div>
    `)
    .join("");
}

function renderWarningDuty(items) {
  const container = document.getElementById("warning-duty-board");
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = "";
    setVisibility("warning-duty-empty", true);
    return;
  }

  setVisibility("warning-duty-empty", false);
  container.innerHTML = items
    .map((item) => `
      <div class="duty-item">
        <span>${escapeHtml(item.name)}</span>
        <strong>${escapeHtml(item.summary)}</strong>
      </div>
    `)
    .join("");
}

function renderWarningTable(items) {
  const tableBody = document.getElementById("warning-table-body");
  const emptyState = document.getElementById("warning-table-empty");
  if (!tableBody || !emptyState) {
    return;
  }

  if (!items.length) {
    tableBody.innerHTML = "";
    emptyState.classList.remove("is-hidden");
    return;
  }

  emptyState.classList.add("is-hidden");
  tableBody.innerHTML = items
    .map((item) => {
      const detailUrl = item.detailUrl || `./detail.html?id=${encodeURIComponent(item.id)}`;
      return `
        <tr>
          <td>${renderTitleStack(item, pageState.warning.translationEnabled, detailUrl)}</td>
          <td>${escapeHtml(item.trigger)}</td>
          <td><span class="badge ${item.levelClass}">${escapeHtml(item.levelText)}</span></td>
          <td>${escapeHtml(item.ownerStatus)}</td>
          <td>
            <div>${escapeHtml(item.advice)}</div>
            <div class="link-group">
              <a class="text-link" href="${escapeHtml(detailUrl)}">事件详情</a>
              <a class="text-link" href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">查看原文</a>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");
}

function renderWarnings(payload) {
  pageState.warning.payload = payload;

  setStatusText("warning-source-status", `后端在线：${payload.sourceName}`);
  setStatusText("warning-updated", `最近更新：${formatDateTime(payload.updatedAt)}`);
  setStatusText("warning-stat-red", formatNumber(payload.stats.red));
  setStatusText("warning-stat-orange", formatNumber(payload.stats.orange));
  setStatusText("warning-stat-yellow", formatNumber(payload.stats.yellow));
  setStatusText("warning-stat-closed", formatNumber(payload.stats.closed));

  renderWarningRules(payload.rules || []);
  renderWarningDuty(payload.duty || []);
  renderWarningTable(payload.warnings || []);
  setWarningTranslationButtonLabel();
}

async function loadWarnings(forceRefresh = false) {
  try {
    setButtonLabel('[data-action="refresh-warning"]', forceRefresh ? "正在刷新..." : "刷新预警", true);
    const payload = await requestJson(appendRefreshParam("/api/warnings", forceRefresh));
    renderWarnings(payload);
  } catch (error) {
    console.error(error);
    setStatusText("warning-source-status", "后端请求失败");
    setStatusText("warning-updated", "最近更新：--");
    showToast("预警中心暂时无法获取后端数据，请确认本地服务已启动。");
  } finally {
    setButtonLabel('[data-action="refresh-warning"]', "刷新预警", false);
  }
}

function initDashboardPage() {
  const refreshButton = document.querySelector('[data-action="refresh-dashboard"]');
  const translationButton = document.querySelector('[data-action="toggle-dashboard-translation"]');

  if (refreshButton) {
    refreshButton.addEventListener("click", () => {
      loadDashboard(true);
    });
  }

  if (translationButton) {
    translationButton.addEventListener("click", () => {
      pageState.dashboard.translationEnabled = !pageState.dashboard.translationEnabled;
      writePreference("dashboard_translation", pageState.dashboard.translationEnabled);
      if (pageState.dashboard.payload) {
        renderDashboard(pageState.dashboard.payload);
      } else {
        setDashboardTranslationButtonLabel();
      }
    });
  }

  setDashboardTranslationButtonLabel();
  loadDashboard(true);
  pageState.dashboard.timer = window.setInterval(() => {
    loadDashboard(true);
  }, PAGE_REFRESH_MS);
}

function initMonitorPage() {
  const chips = Array.from(document.querySelectorAll(".filter-bar [data-filter]"));
  const refreshButton = document.querySelector('[data-action="refresh-monitor"]');
  const translationButton = document.querySelector('[data-action="toggle-monitor-translation"]');

  chips.forEach((chip) => {
    chip.addEventListener("click", () => {
      const filter = chip.dataset.filter || "all";
      chips.forEach((otherChip) => {
        const isActive = otherChip === chip;
        otherChip.classList.toggle("chip-active", isActive);
        otherChip.setAttribute("aria-pressed", String(isActive));
      });

      loadMonitor(filter, true);
    });
  });

  if (refreshButton) {
    refreshButton.addEventListener("click", () => {
      loadMonitor(pageState.monitor.currentFilter, true);
    });
  }

  if (translationButton) {
    translationButton.addEventListener("click", () => {
      pageState.monitor.translationEnabled = !pageState.monitor.translationEnabled;
      writePreference("monitor_translation", pageState.monitor.translationEnabled);
      if (pageState.monitor.payload) {
        renderMonitor(pageState.monitor.payload);
      } else {
        setMonitorTranslationButtonLabel();
      }
    });
  }

  setMonitorTranslationButtonLabel();
  loadMonitor("all", true);
  pageState.monitor.timer = window.setInterval(() => {
    loadMonitor(pageState.monitor.currentFilter, true);
  }, PAGE_REFRESH_MS);
}

function initDetailPage() {
  const refreshButton = document.querySelector('[data-action="refresh-detail"]');
  const translationButton = document.querySelector('[data-action="toggle-detail-translation"]');
  const initialId = new URLSearchParams(window.location.search).get("id") || "";

  pageState.detail.currentId = initialId;

  if (refreshButton) {
    refreshButton.addEventListener("click", () => {
      loadDetail(pageState.detail.currentId, true);
    });
  }

  if (translationButton) {
    translationButton.addEventListener("click", () => {
      pageState.detail.translationEnabled = !pageState.detail.translationEnabled;
      writePreference("detail_translation", pageState.detail.translationEnabled);
      if (pageState.detail.payload) {
        renderDetail(pageState.detail.payload);
      } else {
        setDetailTranslationButtonLabel();
      }
    });
  }

  setDetailTranslationButtonLabel();
  loadDetail(initialId, true);
  pageState.detail.timer = window.setInterval(() => {
    loadDetail(pageState.detail.currentId, true);
  }, PAGE_REFRESH_MS);
}

function initWarningPage() {
  const refreshButton = document.querySelector('[data-action="refresh-warning"]');
  const translationButton = document.querySelector('[data-action="toggle-warning-translation"]');

  if (refreshButton) {
    refreshButton.addEventListener("click", () => {
      loadWarnings(true);
    });
  }

  if (translationButton) {
    translationButton.addEventListener("click", () => {
      pageState.warning.translationEnabled = !pageState.warning.translationEnabled;
      writePreference("warning_translation", pageState.warning.translationEnabled);
      if (pageState.warning.payload) {
        renderWarnings(pageState.warning.payload);
      } else {
        setWarningTranslationButtonLabel();
      }
    });
  }

  setWarningTranslationButtonLabel();
  loadWarnings(true);
  pageState.warning.timer = window.setInterval(() => {
    loadWarnings(true);
  }, PAGE_REFRESH_MS);
}

function initPrototypeButtons() {
  document.querySelectorAll("button").forEach((button) => {
    if (activeButtonSelectors.some((selector) => button.matches(selector))) {
      return;
    }

    button.addEventListener("click", () => {
      showToast(`${button.textContent.trim()}功能仍在原型阶段，后续可以继续接业务流程。`);
    });
  });
}

if (currentPage === "dashboard") {
  initDashboardPage();
}

if (currentPage === "monitor") {
  initMonitorPage();
}

if (currentPage === "detail") {
  initDetailPage();
}

if (currentPage === "warning") {
  initWarningPage();
}

initPrototypeButtons();
